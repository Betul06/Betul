
## 1. Login root account

## 2. Giving billing permission to admin iam user
### 2.1. Open Account

![](images/29_open_account_for_billing.png)

------------------------

### 2.2. Edit iam user billing information 

![](images/30_iam_user_access_billing_information.png)

--------------------------

![](images/31_iam_user_access_activate.png)

--------------------------

## 2.3. logout

## 3. Login admin iam use account

### 3.1. Open Account

![](images/32_iam_user_account.png)

--------------------

![](images/33_budgets.png)

--------------------

![](images/34_create_a_budget.png)

-------------------

![](images/35_select_cost_budget.png)

-------------------

- Budget name: Monthly10
- Enter your budgeted amount ($): 10

Leave rest of the options as they are.

![](images/36_budget_options.png)

----------------------

![](images/37_configure_alerts.png)

---------------------

![](images/38_budget_alert.png)

-----------------------

## 3.2 Next

## 3.3. Create Budget
